﻿Audiolize Widget for WordPress.

Automatically injects Audiolize functionality in WordPress articles.

USAGE:

1.) Install the plugin using WordPress administrative panel.
2.) You can add <?php audiolize_widget();?> within any WordPress theme you want to use the plugin.

Example: 
	Edit content.php of your default theme and add <?php audiolize_widget();?> immediately before <div class="entry-content">.

3) Sign in your audiolize.net content provider account and load any article from you WordPress page. The Audiolize widget should be visible.
